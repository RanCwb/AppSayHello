import React from 'react';
import { View, Text } from 'react-native';

function PostsUser(){
  return(
    <View>
      <Text>TELA POSTS USER</Text>
    </View>
  )
}

export default PostsUser;