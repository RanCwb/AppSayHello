import React from 'react';
import { View, Text } from 'react-native';

function Search(){
  return(
    <View>
      <Text>TELA PROCURAR</Text>
    </View>
  )
}

export default Search;